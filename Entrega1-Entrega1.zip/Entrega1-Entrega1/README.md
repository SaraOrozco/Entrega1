Entrega 1 Sara Orozco
Para correr el programa: node datos
Nota: Se debe correr npm install