let cursos = [
    {
      id: 01,
      nombre: "programación",
      duracion: 60,
      valor: 1500000
    },
    {
      id: 02,
      nombre: "Cálculo",
      duracion: 42,
      valor: 800000
    },
    {
      id: 03,
      nombre: "Lenguajes",
      duracion: 30,
      valor: 600000
    }
  ]
  module.exports = { cursos }